﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTringulo
{
    public partial class Form1 : Form    
    {
        double valA, valB, valC;

        private void txtValB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValB.Text, out valB))
            {
                MessageBox.Show("Valor de B inválido");
                txtValB.Focus();
            }
        }

        private void txtValC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValC.Text, out valC))
            {
                MessageBox.Show("Valor de C inválido");
                txtValC.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (valA + valB > valC && valA + valC > valB && valB + valC > valA)
            {
                if (valA == valB && valA == valC && valB == valC)
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if (valA == valB || valA == valC || valB == valC)
                {
                    MessageBox.Show("Triângulo Isósceles");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é um triângulo");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValA_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtValA.Text, out valA)) 
            {
                MessageBox.Show("Valor de A inválido");
                txtValA.Focus();
            }
        }
    }
}
