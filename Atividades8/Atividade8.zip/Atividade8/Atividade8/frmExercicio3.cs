﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace PTesteMetodos2
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string frase1 = txtboxP.Text;
            frase1 = frase1.Replace(" ", "").Replace(".", "").Replace(",", "").Replace("?", "").Replace("!", "");
            frase1 = frase1.ToUpper();

            char[] frase2 = frase1.ToCharArray();
            char[] FraseReversa = new char[frase2.Length];

            Array.Copy(frase2, FraseReversa, frase2.Length);
            Array.Reverse(FraseReversa);

            int cont = 0;

            if (frase2.Length > 50)
                MessageBox.Show("Informe uma frase com menos do que 50 caracteres!");
            else
            {

                for (int i = 0; i < frase2.Length; i++)
                {
                    if (frase2[i] != FraseReversa[i])
                        break;
                    else
                        cont++;
                }

                if (cont == frase2.Length)
                    MessageBox.Show("É palíndromo");
                else
                    MessageBox.Show("Não é palíndromo");
            }

        }
    }
}
