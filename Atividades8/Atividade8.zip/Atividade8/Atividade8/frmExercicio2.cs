﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos2
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double NumN, H, cont;
            H = 0;
            try
            {
               NumN = int.Parse(txtbox1.Text); 

                if (NumN > 0)
                {
                    for (cont = 1; cont < NumN; cont++)
                    {
                       H = H + 1/cont;
                    }
                   
                    H = H + 1/NumN;

                    MessageBox.Show("O valor de H é:  " + H);
                }

                else
                    MessageBox.Show("Informe um valor maior que 0");
                    txtbox1.Clear();

            }
            catch (Exception)
            {
                MessageBox.Show("Insira um número");
            }
        }
    }
}
