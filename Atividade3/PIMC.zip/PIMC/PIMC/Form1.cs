﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;
        string classificacao;

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if((!Double.TryParse(txtPeso.Text,out peso)) ||(peso <= 0))
            {
                MessageBox.Show("Peso Inválido");
                txtPeso.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtAltura.Text, out altura)) || (altura <= 0))
            {
                MessageBox.Show("Altura Inválida");
                txtAltura.Focus();
            }
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            IMC = peso / (altura * altura);
            IMC = Math.Round(IMC, 1);
            txtIMC.Text = IMC.ToString();

            if (IMC < 18.5)
            {
                classificacao = "Magreza";
            }
            else if (IMC < 25)
            {
                classificacao = "Normal";
            }
            else if (IMC < 30)
            {
                classificacao = "Sobrepeso";
            }
            else if (IMC < 40)
            {
                classificacao = "Obesidade";
            }
            else
            {
                classificacao = "Obesidade Grave";
            }
            txtClass.Text = classificacao;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtIMC.Clear();
            txtClass.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
