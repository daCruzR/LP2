﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstMat_Click(object sender, EventArgs e)
        {
            horista objHorista = new horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtnumHor.Text);
            objHorista.DataEntregaEmpresa = Convert.ToDateTime(txtDataEntEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);
            MessageBox.Show("Nome:" + objHorista.NomeEmpregado + "\n" + "Matricula:" + 
                objHorista.TempoTrabalho()+ "\n" + "Salario:" + 
                objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
