﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtDataEntEmpresa = new System.Windows.Forms.TextBox();
            this.txtSalMen = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnInstMatePar = new System.Windows.Forms.Button();
            this.btnInstMat = new System.Windows.Forms.Button();
            this.Matricula = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(442, 77);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 26);
            this.txtMatricula.TabIndex = 0;
            // 
            // txtDataEntEmpresa
            // 
            this.txtDataEntEmpresa.Location = new System.Drawing.Point(442, 173);
            this.txtDataEntEmpresa.Name = "txtDataEntEmpresa";
            this.txtDataEntEmpresa.Size = new System.Drawing.Size(100, 26);
            this.txtDataEntEmpresa.TabIndex = 1;
            // 
            // txtSalMen
            // 
            this.txtSalMen.Location = new System.Drawing.Point(442, 141);
            this.txtSalMen.Name = "txtSalMen";
            this.txtSalMen.Size = new System.Drawing.Size(100, 26);
            this.txtSalMen.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(442, 109);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 26);
            this.txtNome.TabIndex = 3;
            // 
            // btnInstMatePar
            // 
            this.btnInstMatePar.Location = new System.Drawing.Point(343, 242);
            this.btnInstMatePar.Name = "btnInstMatePar";
            this.btnInstMatePar.Size = new System.Drawing.Size(208, 63);
            this.btnInstMatePar.TabIndex = 4;
            this.btnInstMatePar.Text = "Instanciar Mensalista passando parâmetros";
            this.btnInstMatePar.UseVisualStyleBackColor = true;
            this.btnInstMatePar.Click += new System.EventHandler(this.btnInstMatePar_Click);
            // 
            // btnInstMat
            // 
            this.btnInstMat.Location = new System.Drawing.Point(146, 242);
            this.btnInstMat.Name = "btnInstMat";
            this.btnInstMat.Size = new System.Drawing.Size(191, 63);
            this.btnInstMat.TabIndex = 5;
            this.btnInstMat.Text = "Instanciar Matrícula";
            this.btnInstMat.UseVisualStyleBackColor = true;
            this.btnInstMat.Click += new System.EventHandler(this.btnInstMat_Click);
            // 
            // Matricula
            // 
            this.Matricula.AutoSize = true;
            this.Matricula.Location = new System.Drawing.Point(215, 83);
            this.Matricula.Name = "Matricula";
            this.Matricula.Size = new System.Drawing.Size(77, 20);
            this.Matricula.TabIndex = 6;
            this.Matricula.Text = "Matrícula:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(215, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nome:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(215, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Salário Mensal:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(215, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(221, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Data de Entrada na Empresa:";
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Matricula);
            this.Controls.Add(this.btnInstMat);
            this.Controls.Add(this.btnInstMatePar);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalMen);
            this.Controls.Add(this.txtDataEntEmpresa);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.Load += new System.EventHandler(this.frmMensalista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtDataEntEmpresa;
        private System.Windows.Forms.TextBox txtSalMen;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnInstMatePar;
        private System.Windows.Forms.Button btnInstMat;
        private System.Windows.Forms.Label Matricula;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}