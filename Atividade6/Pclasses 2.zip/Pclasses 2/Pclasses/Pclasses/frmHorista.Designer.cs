﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Matricula = new System.Windows.Forms.Label();
            this.btnInstMat = new System.Windows.Forms.Button();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalHor = new System.Windows.Forms.TextBox();
            this.txtDataEntEmpresa = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtnumHor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFaltas = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(229, 253);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(195, 20);
            this.label4.TabIndex = 19;
            this.label4.Text = "Data Entrada na Empresa";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(229, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "Salário por Hora";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(229, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 17;
            this.label2.Text = "Nome:";
            // 
            // Matricula
            // 
            this.Matricula.AutoSize = true;
            this.Matricula.Location = new System.Drawing.Point(229, 117);
            this.Matricula.Name = "Matricula";
            this.Matricula.Size = new System.Drawing.Size(77, 20);
            this.Matricula.TabIndex = 16;
            this.Matricula.Text = "Matrícula:";
            // 
            // btnInstMat
            // 
            this.btnInstMat.Location = new System.Drawing.Point(232, 323);
            this.btnInstMat.Name = "btnInstMat";
            this.btnInstMat.Size = new System.Drawing.Size(323, 63);
            this.btnInstMat.TabIndex = 15;
            this.btnInstMat.Text = "Instanciar Matrícula";
            this.btnInstMat.UseVisualStyleBackColor = true;
            this.btnInstMat.Click += new System.EventHandler(this.btnInstMat_Click);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(456, 143);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 26);
            this.txtNome.TabIndex = 13;
            // 
            // txtSalHor
            // 
            this.txtSalHor.Location = new System.Drawing.Point(456, 175);
            this.txtSalHor.Name = "txtSalHor";
            this.txtSalHor.Size = new System.Drawing.Size(100, 26);
            this.txtSalHor.TabIndex = 12;
            // 
            // txtDataEntEmpresa
            // 
            this.txtDataEntEmpresa.Location = new System.Drawing.Point(455, 250);
            this.txtDataEntEmpresa.Name = "txtDataEntEmpresa";
            this.txtDataEntEmpresa.Size = new System.Drawing.Size(100, 26);
            this.txtDataEntEmpresa.TabIndex = 11;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(456, 111);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 26);
            this.txtMatricula.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(228, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Número de Horas";
            // 
            // txtnumHor
            // 
            this.txtnumHor.Location = new System.Drawing.Point(455, 212);
            this.txtnumHor.Name = "txtnumHor";
            this.txtnumHor.Size = new System.Drawing.Size(100, 26);
            this.txtnumHor.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(230, 285);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 20);
            this.label5.TabIndex = 23;
            this.label5.Text = "Dias de Faltas";
            // 
            // txtFaltas
            // 
            this.txtFaltas.Location = new System.Drawing.Point(456, 282);
            this.txtFaltas.Name = "txtFaltas";
            this.txtFaltas.Size = new System.Drawing.Size(100, 26);
            this.txtFaltas.TabIndex = 22;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtFaltas);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtnumHor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Matricula);
            this.Controls.Add(this.btnInstMat);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalHor);
            this.Controls.Add(this.txtDataEntEmpresa);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Matricula;
        private System.Windows.Forms.Button btnInstMat;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalHor;
        private System.Windows.Forms.TextBox txtDataEntEmpresa;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtnumHor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFaltas;
    }
}