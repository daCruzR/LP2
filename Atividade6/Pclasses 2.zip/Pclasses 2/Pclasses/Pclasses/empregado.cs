﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
   abstract internal class empregado
    {
        private int matricula; //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula //propriedade
        {
            get { return matricula; }
            set { matricula = value; }
        }
            public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }
        public DateTime DataEntregaEmpresa
        { 
        get { return dataEntradaEmpresa; }
        set {  dataEntradaEmpresa = value;}
        }
        //Método são açoes/comportamentos
        //virtual--> pode ser sobreescrito
        public virtual int TempoTrabalho()
        {
            //representa um intervalo de tmepo 
            TimeSpan span =
                DateTime.Today.Subtract(DataEntregaEmpresa);
            return (span.Days);
        }

        public abstract double SalarioBruto();

        public empregado()
        {
            System.Windows.Forms.MessageBox.Show("aqui é empregado");
        }
        public empregado (int mat, string nome, DateTime datax)
        {
            matricula = mat;
            nomeEmpregado = nome;
            dataEntradaEmpresa = datax;
        }
    }
}
