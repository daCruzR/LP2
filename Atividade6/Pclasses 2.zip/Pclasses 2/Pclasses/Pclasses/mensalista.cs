﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class mensalista: empregado
    { 
        public Double SalarioMensal { get; set; }

        public override double SalarioBruto()
        {
           return SalarioMensal;
        }

        public mensalista()
        {
            System.Windows.Forms.MessageBox.Show("aqui é mensalista");
        }

        public mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntregaEmpresa = datax;
            this.SalarioMensal = salx;
        }
        public static String Empresa = "Toyota";
        public const String Filial = "Filial Sorocaba";
    }
}
