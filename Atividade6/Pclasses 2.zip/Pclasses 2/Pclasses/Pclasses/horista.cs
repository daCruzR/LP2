﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class horista: empregado
    {
        public Double SalarioHora { get; set; }
        public Double NumeroHora { get; set; }

        public int DiasFalta { get; set; }

        public override double SalarioBruto()
        {
            return SalarioHora * NumeroHora;
        }

        public override int TempoTrabalho()
        {
            TimeSpan span =
                DateTime.Today.Subtract(DataEntregaEmpresa);
            return (Convert.ToInt32(span.Days - DiasFalta));
        }
    }
}
