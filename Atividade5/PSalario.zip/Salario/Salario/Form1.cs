﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salario
{
    public partial class Form1 : Form
    {
        double salario, salariototal;
        double desconINSS, descIMP, salarioFamilia;
        int qtdfilhos;

        public Form1()
        {
            InitializeComponent();
            
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            
    }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) ||
Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("caracter inválido"); SendKeys.Send("{BACKSPACE}");
            }
        }

        private void mskbxSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalario.Text, out salario)) {
                MessageBox.Show("Entrada de Salario inválida");
                mskbxSalario.Focus(); 
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            
            


         
             if (salario <= 800.47) // DESC INSS
            {   
                txtAliqinss.Text = "7,65%";
                txtAliqinss.Focus();
                desconINSS = 0.0765 * salario;
                txtDescinss.Text = desconINSS.ToString();

                

            }
            else if(salario <= 1050)
            {
                txtAliqinss.Text = "8,65%";
                desconINSS = ((8.65 / 100) * salario);
                txtDescinss.Text = desconINSS.ToString();
            }
            else if (salario <= 1400.77)
            {
                txtAliqinss.Text = "9%";
                desconINSS = ((9 / 100) * salario);
                txtDescinss.Text = desconINSS.ToString();
            }
            else if (salario <= 2801.56)
            {
                txtAliqinss.Text = "11%";
                desconINSS = ((11 / 100) * salario);
                txtDescinss.Text = desconINSS.ToString();
            }
            else if (salario > 2801.56)
            {
                txtAliqinss.Text = "308.17";
                desconINSS = 308.17;
                txtDescinss.Text = desconINSS.ToString();
            }
             
            
            
            if(salario <= 1257) //IRPF
            {
                txtDescimp.Text = "0";
                txtAliqimp.Text = "Isento";
            }
             else if (salario <= 2512.08)
            {
                descIMP = salario*0.15;
                txtDescimp.Text = descIMP.ToString();
                txtAliqimp.Text = "Isento";
            }
            else
            {
                descIMP = salario * 0.275;
                txtDescimp.Text = descIMP.ToString() ;
                txtAliqimp.Text = "27,5%";
            }

            // SALARIO FAMILIA

            if (salario <= 435.52)
            {
                salarioFamilia = qtdfilhos * 22.3;
                txtSalfamilia.Text = salarioFamilia.ToString();
            }
            else if (salario <= 654.61)
            {
                salarioFamilia = qtdfilhos * 15.7;
                txtSalfamilia.Text = salarioFamilia.ToString();
            }
            else
            {
                salarioFamilia = 0;
                txtSalfamilia.Text = salarioFamilia.ToString();
            }

            salariototal = salario - descIMP - desconINSS + salarioFamilia;
            txtSalliquido.Text = salariototal.ToString();
        }


    }
}