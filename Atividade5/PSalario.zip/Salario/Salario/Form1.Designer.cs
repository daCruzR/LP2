﻿namespace Salario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNome1 = new System.Windows.Forms.Label();
            this.txtSalBruto = new System.Windows.Forms.Label();
            this.txtFIlhos = new System.Windows.Forms.Label();
            this.txtAliqinss1 = new System.Windows.Forms.Label();
            this.txtAliqimp1 = new System.Windows.Forms.Label();
            this.txtSalfamilia1 = new System.Windows.Forms.Label();
            this.txtSalliquido1 = new System.Windows.Forms.Label();
            this.txtDescinss1 = new System.Windows.Forms.Label();
            this.txtDescimp1 = new System.Windows.Forms.Label();
            this.txtAliqinss = new System.Windows.Forms.TextBox();
            this.txtAliqimp = new System.Windows.Forms.TextBox();
            this.txtSalfamilia = new System.Windows.Forms.TextBox();
            this.txtSalliquido = new System.Windows.Forms.TextBox();
            this.txtDescinss = new System.Windows.Forms.TextBox();
            this.txtDescimp = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.mskbxSalario = new System.Windows.Forms.MaskedTextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNome1
            // 
            this.txtNome1.AutoSize = true;
            this.txtNome1.Location = new System.Drawing.Point(138, 49);
            this.txtNome1.Name = "txtNome1";
            this.txtNome1.Size = new System.Drawing.Size(137, 20);
            this.txtNome1.TabIndex = 0;
            this.txtNome1.Text = "Nome funcionário:";
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.AutoSize = true;
            this.txtSalBruto.Location = new System.Drawing.Point(138, 87);
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(101, 20);
            this.txtSalBruto.TabIndex = 1;
            this.txtSalBruto.Text = "Salário Bruto";
            // 
            // txtFIlhos
            // 
            this.txtFIlhos.AutoSize = true;
            this.txtFIlhos.Location = new System.Drawing.Point(138, 123);
            this.txtFIlhos.Name = "txtFIlhos";
            this.txtFIlhos.Size = new System.Drawing.Size(136, 20);
            this.txtFIlhos.TabIndex = 2;
            this.txtFIlhos.Text = "Número dos filhos";
            // 
            // txtAliqinss1
            // 
            this.txtAliqinss1.AutoSize = true;
            this.txtAliqinss1.Location = new System.Drawing.Point(138, 342);
            this.txtAliqinss1.Name = "txtAliqinss1";
            this.txtAliqinss1.Size = new System.Drawing.Size(109, 20);
            this.txtAliqinss1.TabIndex = 3;
            this.txtAliqinss1.Text = "Aliquota INSS";
            // 
            // txtAliqimp1
            // 
            this.txtAliqimp1.AutoSize = true;
            this.txtAliqimp1.Location = new System.Drawing.Point(138, 384);
            this.txtAliqimp1.Name = "txtAliqimp1";
            this.txtAliqimp1.Size = new System.Drawing.Size(108, 20);
            this.txtAliqimp1.TabIndex = 4;
            this.txtAliqimp1.Text = "Aliquota IRPF";
            // 
            // txtSalfamilia1
            // 
            this.txtSalfamilia1.AutoSize = true;
            this.txtSalfamilia1.Location = new System.Drawing.Point(138, 432);
            this.txtSalfamilia1.Name = "txtSalfamilia1";
            this.txtSalfamilia1.Size = new System.Drawing.Size(112, 20);
            this.txtSalfamilia1.TabIndex = 5;
            this.txtSalfamilia1.Text = "Salário Familia";
            // 
            // txtSalliquido1
            // 
            this.txtSalliquido1.AutoSize = true;
            this.txtSalliquido1.Location = new System.Drawing.Point(138, 468);
            this.txtSalliquido1.Name = "txtSalliquido1";
            this.txtSalliquido1.Size = new System.Drawing.Size(113, 20);
            this.txtSalliquido1.TabIndex = 6;
            this.txtSalliquido1.Text = "Salário Líquido";
            // 
            // txtDescinss1
            // 
            this.txtDescinss1.AutoSize = true;
            this.txtDescinss1.Location = new System.Drawing.Point(793, 384);
            this.txtDescinss1.Name = "txtDescinss1";
            this.txtDescinss1.Size = new System.Drawing.Size(120, 20);
            this.txtDescinss1.TabIndex = 7;
            this.txtDescinss1.Text = "Desconto INSS";
            // 
            // txtDescimp1
            // 
            this.txtDescimp1.AutoSize = true;
            this.txtDescimp1.Location = new System.Drawing.Point(793, 432);
            this.txtDescimp1.Name = "txtDescimp1";
            this.txtDescimp1.Size = new System.Drawing.Size(119, 20);
            this.txtDescimp1.TabIndex = 8;
            this.txtDescimp1.Text = "Desconto IRPF";
            // 
            // txtAliqinss
            // 
            this.txtAliqinss.Enabled = false;
            this.txtAliqinss.Location = new System.Drawing.Point(254, 342);
            this.txtAliqinss.Name = "txtAliqinss";
            this.txtAliqinss.Size = new System.Drawing.Size(145, 26);
            this.txtAliqinss.TabIndex = 9;
            // 
            // txtAliqimp
            // 
            this.txtAliqimp.Enabled = false;
            this.txtAliqimp.Location = new System.Drawing.Point(252, 381);
            this.txtAliqimp.Name = "txtAliqimp";
            this.txtAliqimp.Size = new System.Drawing.Size(145, 26);
            this.txtAliqimp.TabIndex = 10;
            // 
            // txtSalfamilia
            // 
            this.txtSalfamilia.Enabled = false;
            this.txtSalfamilia.Location = new System.Drawing.Point(252, 426);
            this.txtSalfamilia.Name = "txtSalfamilia";
            this.txtSalfamilia.Size = new System.Drawing.Size(145, 26);
            this.txtSalfamilia.TabIndex = 11;
            // 
            // txtSalliquido
            // 
            this.txtSalliquido.Enabled = false;
            this.txtSalliquido.Location = new System.Drawing.Point(252, 468);
            this.txtSalliquido.Name = "txtSalliquido";
            this.txtSalliquido.Size = new System.Drawing.Size(145, 26);
            this.txtSalliquido.TabIndex = 12;
            // 
            // txtDescinss
            // 
            this.txtDescinss.Enabled = false;
            this.txtDescinss.Location = new System.Drawing.Point(919, 381);
            this.txtDescinss.Name = "txtDescinss";
            this.txtDescinss.Size = new System.Drawing.Size(145, 26);
            this.txtDescinss.TabIndex = 13;
            // 
            // txtDescimp
            // 
            this.txtDescimp.Enabled = false;
            this.txtDescimp.Location = new System.Drawing.Point(919, 426);
            this.txtDescimp.Name = "txtDescimp";
            this.txtDescimp.Size = new System.Drawing.Size(145, 26);
            this.txtDescimp.TabIndex = 14;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(537, 235);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(145, 65);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Verifica Desconto";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // mskbxSalario
            // 
            this.mskbxSalario.Location = new System.Drawing.Point(281, 84);
            this.mskbxSalario.Name = "mskbxSalario";
            this.mskbxSalario.Size = new System.Drawing.Size(170, 26);
            this.mskbxSalario.TabIndex = 2;
            this.mskbxSalario.Validated += new System.EventHandler(this.mskbxSalario_Validated);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(281, 46);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(306, 26);
            this.txtNome.TabIndex = 1;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(281, 123);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 26);
            this.numericUpDown1.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1151, 611);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.mskbxSalario);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtDescimp);
            this.Controls.Add(this.txtDescinss);
            this.Controls.Add(this.txtSalliquido);
            this.Controls.Add(this.txtSalfamilia);
            this.Controls.Add(this.txtAliqimp);
            this.Controls.Add(this.txtAliqinss);
            this.Controls.Add(this.txtDescimp1);
            this.Controls.Add(this.txtDescinss1);
            this.Controls.Add(this.txtSalliquido1);
            this.Controls.Add(this.txtSalfamilia1);
            this.Controls.Add(this.txtAliqimp1);
            this.Controls.Add(this.txtAliqinss1);
            this.Controls.Add(this.txtFIlhos);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.txtNome1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtNome1;
        private System.Windows.Forms.Label txtSalBruto;
        private System.Windows.Forms.Label txtFIlhos;
        private System.Windows.Forms.Label txtAliqinss1;
        private System.Windows.Forms.Label txtAliqimp1;
        private System.Windows.Forms.Label txtSalfamilia1;
        private System.Windows.Forms.Label txtSalliquido1;
        private System.Windows.Forms.Label txtDescinss1;
        private System.Windows.Forms.Label txtDescimp1;
        private System.Windows.Forms.TextBox txtAliqinss;
        private System.Windows.Forms.TextBox txtAliqimp;
        private System.Windows.Forms.TextBox txtSalfamilia;
        private System.Windows.Forms.TextBox txtSalliquido;
        private System.Windows.Forms.TextBox txtDescinss;
        private System.Windows.Forms.TextBox txtDescimp;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.MaskedTextBox mskbxSalario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
    }
}

