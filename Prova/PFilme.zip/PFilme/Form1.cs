﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        float media1, media2;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbFilmes.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            float[,] notas = new float[2, 2];

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    var entrada = Interaction.InputBox($"insira a nota do {j + 1}° filme", "Entrada de dados");
                    if (entrada == "")
                    {
                        return;
                    }
                    if (float.TryParse(entrada, out notas[i, j]))
                    {
                        if (notas[i, j] < 0 || notas[i, j] > 10)
                        {
                            MessageBox.Show("Valor Inválido");
                        }
                        else
                        {
                            media1 = (notas[0, 0] + notas[0, 1]) / 2;
                            media2 = (notas[1, 0] + notas[1, 1]) / 2;


                        }

                    }

                }
                


            }
            lbFilmes.Items.Add($"Pessoa 1, Nota Filme 1: {notas[0, 0].ToString()}," +
                    $"Nota Filme 2: {notas[0, 1]}");
            lbFilmes.Items.Add($"Pessoa 2, Nota Filme 1: {notas[1, 0].ToString()}," +
                $"Nota Filme 2: {notas[1, 1]}");

            lbFilmes.Items.Add("--------------------");
            lbFilmes.Items.Add($"Media Filme 1: {(media1)}");
            lbFilmes.Items.Add($"Media Filme 2: {(media2)}");
        }
    }
}
